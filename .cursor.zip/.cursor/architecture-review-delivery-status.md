# TS Review: Order Payment and Delivery Status Architecture

**Date:** 2026-04-21
**Reviewer:** AI Agent
**Status:** APPROVED WITH COMMENTS

## Overall Assessment
The user raised an architectural concern regarding the split of `order-status` and `order-delivery-status`, and the addition of `syncPendingOrderStatusByPaymentId` (a fallback payment verification) into the `order-delivery-status` endpoint. 

The review confirms the user's suspicion: the fallback is a symptom of a larger architectural issue—specifically a race condition (read-after-write or eventual consistency) caused by the frontend rapidly switching from polling endpoint A to endpoint B. To compensate, endpoint B was forced to duplicate the payment verification logic of endpoint A. 

## Critical Issues (🔴 BLOCKING)
None. The code currently works as a pragmatic safeguard, but it degrades the architecture.

## Major Issues (🟡 MAJOR)

### 1. Duplicated Responsibility (Payment Reconciliation)
- **Location:** `app/api/order-status/route.ts` and `app/api/order-delivery-status/route.ts`
- **Problem:** The entire `syncPendingOrderStatusByPaymentId` block is copy-pasted across both endpoints.
- **Why it matters:** This is a clear violation of DRY and blurs the domain boundaries. `order-delivery-status` now acts as a secondary payment reconciler. If the payment verification logic needs to change (e.g., handling new YooKassa statuses), both files must be updated.
- **Recommendation:** Extract the payment reconciliation logic into a single shared utility (e.g., in `lib/paid-order-finalization.ts` or a new `lib/payment-reconciliation.ts`). 

### 2. Client-Side Orchestration of Eventual Consistency 
- **Location:** `app/order/result/order-result-content.tsx` and the split endpoints.
- **Problem:** The frontend polls `order-status` until the state is `paid`. Then it immediately fires a request to `order-delivery-status`. Because PocketBase might still return `pending` for the order on this immediate subsequent read (due to eventual consistency or just typical read-after-write latency on the backend), `order-delivery-status` was given the payment verification logic to "heal" the state. 
- **Why it matters:** The architecture is compensating for a race condition created by having two separate polling endpoints. This makes the frontend complex (managing two separate polling lifecycles and timeouts) and forces the backend to duplicate responsibilities.
- **Recommendation:** Simplify the architecture by merging the polling loops. If `order-status` is responsible for both syncing the payment and (if paid) triggering the delivery registration, the race condition disappears completely. The frontend only needs to poll one endpoint that returns the unified state of the order.

## Minor Issues (🟢 MINOR)

### 1. Side Effects in GET Requests
- **Location:** `app/api/order-status/route.ts` and `app/api/order-delivery-status/route.ts`
- **Problem:** Both `GET` endpoints perform significant side effects (verifying with external payment gateways, mutating the database, registering shipments with CDEK).
- **Recommendation:** While often necessary for pragmatic polling, reducing the number of endpoints that perform these side-effects (by merging them) minimizes the surface area of side-effect-heavy `GET` routes. Ideally, the webhook should be the primary driver of state changes, but the polling fallback is still required for UX.

## Final Recommendation

**SIMPLIFY / REDESIGN**

Here are the answers to the user's specific questions based on the review:

1. **Is this fallback payment verification acceptable or a bad sign?**
   It is a bad sign. While intended as a pragmatic safeguard against read-after-write latency (PocketBase returning `pending` right after another endpoint marked it `paid`), duplicating the implementation verbatim across two routes is an architectural smell. 
2. **Does the current split match clean architecture or is there a simpler design?**
   The split introduces unnecessary complexity. A much simpler and cleaner design would be to have a single `order-status` endpoint. This endpoint would verify the payment, and if the order is (or becomes) `paid`, it would immediately attempt/refresh the delivery registration. The UI would only need one polling loop.
3. **What is the core conceptual issue?**
   The core issue is a **race condition + eventual consistency** caused by the frontend switching endpoints. When the UI sees "paid" from endpoint A and immediately calls endpoint B, endpoint B reads stale "pending" data. To fix this, endpoint B was given the **duplicated responsibility** of verifying payments. 
4. **Concrete recommendation: keep, simplify, or redesign?**
   **Simplify (Short-term):** Extract `syncPendingOrderStatusByPaymentId` into a shared library file immediately so the logic isn't duplicated.
   **Redesign (Long-term):** Merge `order-delivery-status` back into `order-status`. The frontend should poll one unified endpoint that handles payment reconciliation and then cascades into delivery registration. This completely eliminates the cross-endpoint race condition and drastically simplifies the React component.