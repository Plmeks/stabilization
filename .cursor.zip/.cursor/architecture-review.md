# Architecture Review: YooKassa payment status + CDEK delivery registration flows

**Date:** 2026-04-21  
**Reviewer:** AI Agent  
**Status:** NEEDS REVISION

## Overall Assessment

Two different HTTP routes are currently allowed to **reconcile payment truth by calling YooKassa** and then **mutate order state in PocketBase**:

- `app/api/order-status/route.ts` (primary customer-facing polling)
- `app/api/order-delivery-status/route.ts` (delivery polling after “paid”, but with a new payment fallback via `paymentId`)

This works and is defensible as an operational fallback, but **the current shape mixes responsibilities and duplicates payment-verification logic** across routes, which is what the user is sensing as “moving away from clean architecture”.

## Critical Issues (🔴 BLOCKING)

None found that make the flow infeasible or unsafe by itself. The fallback is guarded by:

- order access token validation (when required)
- YooKassa `metadata.order_id` match
- amount/currency match

## Important Issues (🟡 MAJOR)

1) Payment reconciliation logic is duplicated across two routes (unclear ownership)
- **Location**:
  - `app/api/order-status/route.ts` → `syncPendingOrderStatusByPaymentId()`
  - `app/api/order-delivery-status/route.ts` → `syncPendingOrderStatusByPaymentId()`
- **Problem**: Both routes implement “payment verification → mapping → reconciliation” inline (same invariants, same error handling, same persistence path).
- **Why it matters**:
  - increases drift risk (one route evolves, the other doesn’t)
  - blurs boundaries: “delivery-status” becomes a second payment reconciler
  - makes it harder to reason about the system’s single source of truth
- **Minimal recommendation**: Extract a single shared function (e.g. in `lib/paid-order-finalization.ts` or a small `lib/payment-reconciliation.ts`) like `syncPendingOrderPaymentStatus(order, { paymentIdOverride, logPrefix })` and call it from both routes. Keep “who can call it” as-is, but make the logic owned by one module.

2) The observed “paid in UI, pending in PocketBase” is a read-after-write anomaly (race / eventual consistency), and the architecture currently compensates in multiple places
- **Location / symptom**:
  - UI calls `order-status` until it sees `status === "paid"`, then begins polling `order-delivery-status` for CDEK registration (`app/order/result/order-result-content.tsx`).
  - `order-delivery-status` sometimes reads the order still as `pending` from PocketBase and must re-verify via YooKassa.
- **Best description**: **race + eventual consistency lag** between “status reconciliation + PB write” and subsequent “PB read for delivery” (or concurrency between webhook, order-status polling, and delivery polling).
- **Minimal recommendation**: Treat reconciliation as an explicit, idempotent domain operation and call the shared reconciler at the boundary where it is required (before any “paid-only” delivery finalization), rather than re-implementing it per-route.

3) `order-delivery-status` is not purely read-only (it can cause side effects), so its contract should be explicit
- **Location**: `app/api/order-delivery-status/route.ts` → `refreshPaidCdekOrderDeliveryStatus()` (may create/register shipment) and now also payment reconciliation.
- **Problem**: Route name and mental model suggest “read delivery status”, but it can mutate both delivery and payment state.
- **Minimal recommendation**:
  - keep current behavior (minimal change) but **codify the contract**: delivery-status is an “ensure delivery state up-to-date” endpoint, not a pure query.
  - or (bigger change) move side effects to webhook/worker and keep delivery-status read-only.

## Minor Issues (🟢 MINOR)

1) Client keeps passing `paymentId` even after “paid” (by state), which is helpful for fallback but broadens coupling
- **Location**: `app/order/result/order-result-content.tsx` (payment id is stored in `sessionStorage`, and the in-memory state may still be set even after storage cleanup).
- **Note**: This is not wrong, but it reinforces the hidden dependency “delivery polling may need payment id to heal PB lag”.
- **Recommendation (optional)**: If you keep the fallback, consider only attaching `paymentId` when the server indicates it is needed (e.g., server returns a flag “paymentReconciliationNeeded”) to reduce incidental coupling.

## Final Recommendation

**RETURN FOR REVISION** — not because the fallback is “wrong”, but because **payment reconciliation ownership should be centralized** to avoid architectural drift.

The smallest concrete change is:

- Extract the duplicated YooKassa verification + `reconcileVerifiedOrderPayment()` call into a single shared library function and reuse it from both routes.
- Keep `order-delivery-status` allowed to call it as a precondition for paid-only delivery finalization, but stop duplicating the logic in the route layer.

