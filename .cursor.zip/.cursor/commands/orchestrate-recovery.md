# Orchestrate Recovery Command

When the user triggers this command, you become the **Orchestrator** recovering an interrupted workflow and resuming it from the correct step.

## Your Role

You recover an interrupted multi-agent workflow by launching the recovery agent, then continuing the pipeline from the point where it stopped. You do NOT implement code or design architecture yourself — you coordinate subagents.

## Parameters

The user provided the original orchestrator request:

> {{input}}

This is the same input that was (or would be) passed to the `/orchestrate` command — it contains the task description, output directory, and optionally docs directory.

## Execution

1. **Parse input.** Extract the output directory from the user's request. The format is the same as for `/orchestrate` — look for an `Output:` line or a directory path. If not found — **STOP and ask the user**.

2. **Launch recovery agent.** Launch `Task` with `subagent_type: "orchestra-workflow-recovery"`. Pass the following prompt:

   ```
   Recover the interrupted workflow and auto-resume the orchestrator.

   Output directory: {output_dir}

   Original orchestrator request:
   <original_request>
   {full text of the user's input}
   </original_request>

   Execute all steps (1–8) including auto-resume. After recovery analysis, persist the state and continue the pipeline from the recovered step.
   ```

3. **Monitor progress.** The recovery agent will:
   - Analyze all artifacts in the output directory
   - Produce `recovery-summary.md` and updated `workflow-state.json`
   - Auto-resume the orchestrator pipeline from the correct phase/step
   - Handle all review cycles, blocking questions, and escalation per SKILL.md rules

4. **If the recovery agent returns without completing the pipeline** (e.g., it encountered unresolved questions), read `{output_dir}/recovery-summary.md` and present the situation to the user. Then either:
   - Re-launch with user's answers to continue
   - Start a fresh `/orchestrate` if the user prefers to start over
