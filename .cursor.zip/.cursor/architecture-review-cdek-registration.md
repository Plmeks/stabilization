# Architecture Review: CDEK registration shared flow

**Date:** 2026-04-21  
**Reviewer:** AI Agent  
**Status:** APPROVED WITH COMMENTS

## Overall Assessment

The production entrypoints for “payment became paid” (YooKassa webhook and the order-status polling endpoint) now converge on a **single shared CDEK registration/follow-up mechanism** implemented in `lib/paid-order-finalization.ts` + `lib/cdek/register-shipment.ts`. Payload construction and the async follow-up after `POST /orders` are shared via `createCdekOrderAttempt()` in `lib/cdek/register-shipment.ts`.

However, the **debug CDEK create-order route does not fully reuse the shared mechanism** at the persistence/result-shaping layer (it reimplements “pending/failed/registered” persistence and payload shape), which creates a potential divergence from production semantics.

## Critical Issues (🔴 BLOCKING)

None found with respect to the stated requirement: **webhook path and order-status polling path share the same CDEK registration path, payload logic, and async follow-up logic**.

## Important Issues (🟡 MAJOR)

1) Debug endpoint partially bypasses shared mechanism
- **Location**: `app/api/debug/cdek-create-order/route.ts`
- **Problem**: The debug route calls `createCdekOrderAttempt()` directly and then **reimplements**:
  - persistence mapping to `delivery_status` (failed/pending/registered)
  - construction of `delivery_provider_payload.registration`
  - success summary concatenation
- **Why it matters**: This violates the “debug path should reuse that mechanism” requirement as stated, and makes it easy for debug to drift from production behavior (e.g., missing recovery checks like `findExistingCdekRegistration()`, different payload metadata, different status handling).
- **Recommendation**: Refactor debug to call the same public “registration unit” used in production (ideally `registerCdekShipment()` + the same persistence helper used by `finalizePaidCdekOrder()`, or reuse a shared persistence-mapper exported from `lib/paid-order-finalization.ts`).

2) Non-distributed idempotency gate (environment-dependent)
- **Location**: `lib/orders.ts` → `acquireOrderDeliveryRegistrationGate()`
- **Problem**: The gate is implemented via a **local filesystem lock** in `tmpdir()` (or `TI_WARM_LAB_ORDER_DELIVERY_GATE_DIR`). This prevents duplicates within the same filesystem namespace, but will not coordinate across multiple hosts/containers.
- **Why it matters**: In horizontally scaled/serverless deployments, concurrent webhook + polling (or multiple concurrent polling) could trigger duplicate CDEK calls before `delivery_provider_order_id` is persisted, potentially creating multiple CDEK orders.
- **Recommendation**: If deployment can run concurrently across isolated instances, use a shared, transactional gate (e.g. PocketBase record-level lock / “compare-and-set” update on `delivery_status` + a unique constraint, Redis lock, etc.).

## Minor Issues (🟢 MINOR)

1) Redundant finalize invocation in order-status path
- **Location**: `app/api/order-status/route.ts` (`syncPendingOrderStatus*()` calls `reconcileVerifiedOrderPayment()` which can call `finalizePaidCdekOrder()`, and then handler calls `finalizePaidCdekOrder()` again).
- **Impact**: Typically harmless due to `canTriggerPaidCdekRegistration()` + gate, but adds noise and extra work.
- **Recommendation**: Consider relying on one call site (either only in `reconcileVerifiedOrderPayment()` or only once after sync) to reduce duplication.

## Notable Residual Risks

- **CDEK eventual consistency window**: `createCdekOrderAttempt()` only polls a small number of times (default `maxFollowUpReads = 2`, delay 2500ms) before returning “pending”. Production relies on re-entry via webhook/polling + the “stale pending” threshold to recover. If traffic is low after payment, pending registrations may remain pending until the next status check.
- **Status-based trigger correctness depends on persistence**: `canTriggerPaidCdekRegistration()` allows registration for `delivery_status === "awaiting_payment"` or stale `registration_pending`. If a paid order ends up in some other intermediate `delivery_status` not covered (future statuses), registration may not trigger.
- **Remote lookup shape assumptions**: `normalizeCdekShipmentRegistration()` expects an `entity` shape; if CDEK `GET /orders?im_number=` returns a list wrapper in some scenarios, normalization could fail and delay recovery.

## Final Recommendation

**APPROVE WITH COMMENTS**: Production webhook and polling paths correctly share the same CDEK registration flow and async follow-up logic. Address the debug endpoint divergence and confirm the gate strategy matches the production deployment topology.

