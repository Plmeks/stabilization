# Architect Reviewer Examples

Reference examples for the `orchestra-architect-reviewer` agent. Read this file when you need guidance on classifying architecture issues.

## Critical Issue Example (🔴 BLOCKING)

```markdown
### 1. Missing entity for storing email confirmation tokens

**Location:** Section 4. Data Model

**Problem:**
The TS (UC-01) describes a registration process with email confirmation via token. However, the data model lacks an entity for storing these tokens.

The current model only contains the `users` table, but there is no `email_confirmations` table or similar.

**Why this is critical:**
Without this entity:
- It's impossible to implement email confirmation functionality
- The planner won't be able to create tasks for implementation
- Developers won't know where to store tokens

**Recommendation:**
Add an `EmailConfirmation` entity:

**Attributes:**
- `id` (UUID, PRIMARY KEY)
- `user_id` (UUID, FOREIGN KEY → users.id)
- `token` (VARCHAR(255), UNIQUE)
- `created_at` (TIMESTAMP)
- `expires_at` (TIMESTAMP)
- `confirmed_at` (TIMESTAMP, nullable)

**Indexes:**
- UNIQUE INDEX on `token`
- INDEX on `user_id`
- INDEX on `expires_at` (for cleanup of expired tokens)

**Business rules:**
- Token is valid for 24 hours
- After confirmation, `confirmed_at` is set
- One user can have only one active token
```

## Major Issue Example (🟡 MAJOR)

```markdown
### 1. Missing indexes for frequent queries

**Location:** Section 4.2. Logical Data Model, `users` table

**Problem:**
The `users` table lacks an index on the `status` field, although the TS (UC-05) describes user filtering by status.

Without an index, queries like `SELECT * FROM users WHERE status = 'active'` will require full table scans, which is critical with a large number of users.

**Recommendation:**
Add an index:
CREATE INDEX idx_users_status ON users(status);

Also consider a composite index if status and date are frequently filtered together:
CREATE INDEX idx_users_status_created ON users(status, created_at);
```

## Minor Issue Example (🟢 MINOR)

```markdown
### 1. Endpoint description can be improved

**Location:** Section 5.1. External API, POST /register

**Recommendation:**
In the 400 response description, more validation error examples can be added:

{
  "error": "validation_error",
  "details": {
    "email": ["Email already exists", "Invalid email format"],
    "password": ["Password too short", "Password must contain at least one digit"]
  }
}

This will help frontend developers handle errors better.
```
