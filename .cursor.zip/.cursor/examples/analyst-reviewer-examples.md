# Analyst Reviewer Examples

Reference examples for the `orchestra-analyst-reviewer` agent. Read this file when you need guidance on classifying issues.

## Critical Issue Example (🔴 BLOCKING)

```markdown
### 1. Use case for password recovery is missing

**Location:** Section 2. List of Use Cases

**Problem:**
The task description explicitly states: "Users must be able to recover their password via email." However, the TS contains no corresponding use case. Only UC-01 "Registration" and UC-02 "Login" are described.

**Why this is critical:**
Without a description of the password recovery process:
- The architect will not design the necessary components (token generation, email sending)
- The planner will not create implementation tasks
- The functionality will not be implemented, even though it is an explicit requirement

**Recommendation:**
Add UC-03 "Password Recovery" describing:
- The main scenario (recovery request → email received → follow link → set new password)
- Alternative scenarios (invalid email, expired link, etc.)
- Acceptance criteria (link lifetime, token format, etc.)
```

## Major Issue Example (🟡 MAJOR)

```markdown
### 1. Incomplete alternative scenarios in UC-01

**Location:** UC-01 "New User Registration", section "Alternative Scenarios"

**Problem:**
Only 3 alternative scenarios are described:
- A1: Invalid email
- A2: Passwords do not match
- A3: Email already taken

The following important cases are not described:
- What happens if the password is too short?
- What happens if the password does not contain required characters?
- What happens if the email service is unavailable?
- What happens if the user did not receive the email?

**Recommendation:**
Add alternative scenarios:
- A4: Password does not meet security requirements
- A5: Email sending error
- A6: Resend confirmation email

Also clarify password requirements in the acceptance criteria (minimum length, required characters).
```

## Minor Issue Example (🟢 MINOR)

```markdown
### 1. Improve acceptance criterion wording

**Location:** UC-01, Acceptance Criteria

**Recommendation:**
Current wording: "Confirmation email is sent quickly"

Better: "Confirmation email is sent within 1 minute of registration"

This makes the criterion measurable and verifiable.
```
