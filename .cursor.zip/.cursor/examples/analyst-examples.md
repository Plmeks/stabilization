# Analyst Examples

Reference examples for the `orchestra-analyst` agent. Read this file when you need guidance on structuring use cases and handling revisions.

## Good Use Case Example

```markdown
### UC-01: New User Registration

**Actors:**
- New user
- System
- Email service (external)

**Preconditions:**
- User is not registered in the system
- User's email address is valid and available

**Main Scenario:**
1. User opens the registration page
2. System displays a form with fields: email, password, confirm password
3. User fills in the form and clicks "Register"
4. System validates the email format
5. System checks that passwords match
6. System checks that the email is not already taken
7. System creates an account with status "unconfirmed"
8. System sends a confirmation code email
9. System displays a "Check your email" page

**Alternative Scenarios:**

**A1: Invalid email (at step 4)**
1. System displays error: "Invalid email address"
2. User corrects the email
3. Return to step 3 of the main scenario

**A2: Passwords do not match (at step 5)**
1. System displays error: "Passwords do not match"
2. User corrects the passwords
3. Return to step 3 of the main scenario

**A3: Email already taken (at step 6)**
1. System displays error: "A user with this email already exists"
2. System suggests logging in or resetting the password
3. End of use case

**Postconditions:**
- Account created with status "unconfirmed"
- Confirmation email sent
- User sees a page with instructions to check email

**Acceptance Criteria:**
- ✅ Registration form contains all required fields
- ✅ Email is validated per RFC 5322
- ✅ Password must be at least 8 characters
- ✅ System does not allow duplicate email registration
- ✅ Confirmation email is sent within 1 minute
- ✅ Confirmation code is valid for 24 hours
- ✅ All errors are displayed with clear messages
```

## Bad Use Case Example

```markdown
### Registration

User registers in the system.

**Acceptance Criteria:**
- Registration works
```

❌ **Problems:**
- No structure
- No details
- No alternative scenarios
- Acceptance criteria are not verifiable

## Working with Reviewer Feedback

When you receive reviewer feedback:

1. **Carefully read each comment**
2. **Find the corresponding section in the TS**
3. **Fix ONLY the specified issue**
4. **Do NOT change other parts of the document**
5. **Preserve numbering and structure**

### Correct Fix Example

**Comment:** "UC-01 does not describe the scenario where the user enters a password that is too short"

**Correct fix:**
Add to alternative scenarios of UC-01:

```markdown
**A4: Password too short (at step 5)**
1. System checks password length
2. System displays error: "Password must be at least 8 characters"
3. User enters a new password
4. Return to step 3 of the main scenario
```

**Incorrect fixes:**
- ❌ Rewrite all of UC-01 from scratch
- ❌ Change the numbering of other use cases
- ❌ Add new requirements unrelated to the comment
