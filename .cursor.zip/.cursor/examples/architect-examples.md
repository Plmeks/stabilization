# Architect Examples

Reference examples for the `orchestra-architect` agent. Read this file when you need guidance on structuring architecture sections.

## Data Model — Relational Database Example

### Conceptual Entity

```markdown
##### Entity: User

**Description:** Registered system user

**Attributes:**
- `id` (UUID) — unique identifier
- `email` (String, unique) — user email
- `password_hash` (String) — password hash
- `created_at` (DateTime) — creation date
- `status` (Enum: pending, active, blocked) — account status

**Relationships:**
- One User has many Sessions (1:N)
- One User has one Profile (1:1)

**Business rules:**
- Email must be unique
- Password must be at least 8 characters
- Default status — pending
```

### Logical Table

```markdown
##### Table: `users`

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PRIMARY KEY | Unique identifier |
| email | VARCHAR(255) | UNIQUE, NOT NULL | User email |
| password_hash | VARCHAR(255) | NOT NULL | Bcrypt password hash |
| created_at | TIMESTAMP | NOT NULL, DEFAULT NOW() | Creation date |
| updated_at | TIMESTAMP | NOT NULL, DEFAULT NOW() | Update date |
| status | VARCHAR(20) | NOT NULL, DEFAULT 'pending' | Account status |

**Indexes:**
- PRIMARY KEY on `id`
- UNIQUE INDEX on `email`
- INDEX on `status` (for filtering)
```

## Data Model — NoSQL Example

```markdown
##### Collection: `users`

Document structure:
- `_id`: ObjectId
- `email`: string (unique)
- `password_hash`: string
- `created_at`: ISODate
- `status`: string (enum: pending, active, blocked)
- `profile`: { first_name, last_name, avatar_url }
- `sessions`: [{ token, created_at, expires_at }]

**Indexes:**
- Unique index on `email`
- Index on `status`
- TTL index on `sessions.expires_at`
```

## ER Diagram Example

```
┌─────────────┐         ┌─────────────┐
│    User     │         │   Session   │
├─────────────┤         ├─────────────┤
│ id (PK)     │────────<│ user_id(FK) │
│ email       │    1:N  │ token       │
│ password    │         │ expires_at  │
└─────────────┘         └─────────────┘
```

## External API Example

```markdown
##### API: User Management API

**Protocol:** REST
**Base URL:** `/api/v1/users`
**Authentication:** JWT Bearer Token

###### POST /register

**Description:** Register a new user
**Related use case:** UC-01

**Request:**
{
  "email": "string (required, email format)",
  "password": "string (required, min 8 chars)",
  "password_confirmation": "string (required)"
}

**Response 201 Created:**
{
  "user_id": "uuid",
  "email": "string",
  "status": "pending",
  "message": "Confirmation email sent"
}

**Response 400 Bad Request:**
{
  "error": "validation_error",
  "details": {
    "email": ["Email already exists"],
    "password": ["Password too short"]
  }
}
```

## Internal Interface Example

```markdown
##### Interface: UserService → EmailService

**Protocol:** Message Queue (RabbitMQ)
**Exchange:** `notifications`
**Routing Key:** `email.confirmation`

**Message Format:**
{
  "user_id": "uuid",
  "email": "string",
  "confirmation_token": "string",
  "template": "user_confirmation"
}
```
