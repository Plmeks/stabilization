---
name: workflow-orchestrator
description: Orchestrates a multi-agent software development workflow with analysis, architecture, planning, and development phases. Each phase includes automated review cycles. Use when the user wants to start a full development workflow, implement a new feature end-to-end, or run the multi-agent pipeline. Trigger on phrases like "start development", "implement feature", "run workflow", "create project", "develop", "build".
---

# Development Workflow Orchestrator

Runs a multi-agent pipeline with review cycles. Supports three pipeline modes based on task complexity: **Simple**, **Medium**, and **Full**.

For prompt templates, see [prompts.md](prompts.md).

## Getting Started

1. **Collect user's task description** — the high-level requirement.
2. **Determine output directory** — **REQUIRED**. If not provided by the user, **STOP and ask**. Accept any path (e.g., `.cursor/tasks/user-auth`, `docs/features/payment`). Do NOT proceed without a confirmed directory.
3. **Determine docs directory** — optional. The directory where project documentation lives (e.g., `call/dev/docs/frontend/`, `im/dev/docs/`). If provided, agents will update documentation there. If not provided, agents skip doc updates. Store as `{docs_dir}`.
4. **Check for existing state** — check if `{output_dir}/recovery-summary.md` or `{output_dir}/workflow-state.json` exists. If found, follow [Workflow Persistence](#workflow-persistence) to resume or start over. **If resuming, skip steps 5–10.**
5. **Classify complexity** — auto-detect or accept explicit level from user (see [Complexity Classification](#complexity-classification)).
6. **Determine context** — new project or enhancement to existing one.
7. **If existing project** — create `{output_dir}/project-context.md` with relevant project docs (README, architecture docs, and content from `{docs_dir}` if provided). Include `docs_dir` path in the file so agents know where to update docs. All agents read this file instead of receiving inline project context.
8. **Create directory structure:**
   ```
   {output_dir}/
   ├── tasks/
   ├── reports/
   └── tests/
   ```
9. **Initialize workflow state** — create `{output_dir}/workflow-state.json` (see [Workflow Persistence](#workflow-persistence)). Include `docs_dir` in the state.
10. **Start the pipeline** — route to the appropriate pipeline based on complexity.

Track progress with TodoWrite tool:

```
- [ ] Phase 1: Analysis
- [ ] Phase 2: Architecture (full pipeline only)
- [ ] Phase 3: Planning
- [ ] Phase 3.5: Pre-flight Check
- [ ] Phase 4: Development (tasks 1-1 through N-M)
```

## Complexity Classification

Complexity determines which pipeline to use. Can be set explicitly by the user or detected automatically.

### Auto-classification

If the user did not specify complexity, classify based on the task description using these criteria:

| Signal | Simple | Medium | Full |
|--------|--------|--------|------|
| Files affected | 1-2 | 3-7 | 8+ or unknown |
| New classes/modules | 0 | 0-2 | 3+ |
| Architecture changes | None | Minor | Significant |
| New contracts/interfaces | No | No | Yes |
| Cross-module impact | No | Possible | Yes |
| Task type | Bug fix, rename, add parameter | New feature in existing module | New module, migration, major refactor |

Present the classification to the user for confirmation:

```
Task classified as: {SIMPLE/MEDIUM/FULL}
Rationale: {brief explanation}
Pipeline: {pipeline description}

Proceed? (or specify a different complexity level)
```

### Pipeline Routes

| Pipeline | Phases | When to use |
|----------|--------|-------------|
| **Simple** | Developer → Developer Reviewer | Bug fixes, renames, small changes in 1-2 files |
| **Medium** | Analysis → Planning → Pre-flight → Development | New feature within existing architecture |
| **Full** | Analysis → Architecture → Planning → Pre-flight → Development | New modules, architectural changes, migrations |

## Simple Pipeline

For trivial tasks. Skip analysis, architecture, and planning.

### Step S.1 — Run Developer

Launch `Task` with `subagent_type: "orchestra-developer"`, `model: "fast"`. Pass the prompt from [prompts.md → Developer: Simple Task](prompts.md#developer-simple-task).

The task description from the user serves as the task specification directly.

### Step S.2 — Run Developer Reviewer

Launch `Task` with `subagent_type: "orchestra-developer-reviewer"`, `model: "fast"`. Pass the prompt from [prompts.md → Developer Reviewer: Simple Task](prompts.md#developer-reviewer-simple-task).

- If approved → **done**
- If changes required → run developer fix → re-review (max 1 fix cycle)

## Medium Pipeline

Skips the Architecture phase. Use when the existing architecture is sufficient.

Executes: Phase 1 (Analysis) → Phase 3 (Planning) → Phase 3.5 (Pre-flight) → Phase 4 (Development).

Follow the same steps as the Full Pipeline below, but **skip Phase 2** entirely. In Phase 3, the planner receives only the TS (no architecture document).

Use `model: "fast"` for reviewer agents in this pipeline to reduce cost.

## Full Pipeline

The complete pipeline with all phases. Follow the phases below.

## Phase 1: Analysis

**Goal:** Produce an approved Technical Specification (TS).

### Step 1.1 — Run Analyst

Launch `Task` with `subagent_type: "orchestra-analyst"`. Pass the prompt from [prompts.md → Analyst: Initial](prompts.md#analyst-initial).

**On completion:**
- Parse the JSON response: `{"ts_file": "...", "blocking_questions": [...]}`
- **Update `workflow-state.json`:** set `phase: 1`, `step: "1.1"`, `artifacts.ts_file` to the returned path
- If `blocking_questions` is non-empty → set `status: "paused"`, **STOP**, present to user, wait for answers, then re-run analyst with answers included
- If empty → proceed to Step 1.2

### Step 1.2 — Run Analyst Reviewer

Launch `Task` with `subagent_type: "orchestra-analyst-reviewer"`. Pass the prompt from [prompts.md → Analyst Reviewer](prompts.md#analyst-reviewer).

**On completion:**
- Parse JSON: `{"review_file": "...", "has_critical_issues": true/false}`
- **Update `workflow-state.json`:** set `step: "1.2"`, `artifacts.ts_review` to the returned path, increment `review_counts.analysis`
- If `has_critical_issues: false` → **Phase 1 complete**, proceed to Phase 2 (or Phase 3 for Medium pipeline)
- If `has_critical_issues: true` AND this is review #1 → proceed to Step 1.3
- If `has_critical_issues: true` AND this is review #2 → set `status: "paused"`, **STOP**, escalate to user

### Step 1.3 — Analyst Revision

Launch `Task` with `subagent_type: "orchestra-analyst"`. Pass the prompt from [prompts.md → Analyst: Revision](prompts.md#analyst-revision).

**On completion:**
- **Update `workflow-state.json`:** set `step: "1.3"`
- Check blocking questions (same as Step 1.1 — update state if paused)
- Return to Step 1.2 for the 2nd review

**Max cycles:** analyst → review → analyst → review (2 reviews, 1 revision)

## Phase 2: Architecture

**Goal:** Produce an approved architecture document. *(Full pipeline only)*

### Step 2.1 — Run Architect

Launch `Task` with `subagent_type: "orchestra-architect"`. Pass the prompt from [prompts.md → Architect: Initial](prompts.md#architect-initial).

**On completion:**
- Parse JSON: `{"architecture_file": "...", "blocking_questions": [...]}`
- **Update `workflow-state.json`:** set `phase: 2`, `step: "2.1"`, `artifacts.architecture_file` to the returned path
- If blocking questions → set `status: "paused"`, **STOP**, present to user
- If empty → proceed to Step 2.2

### Step 2.2 — Run Architecture Reviewer

Launch `Task` with `subagent_type: "orchestra-architect-reviewer"`. Pass the prompt from [prompts.md → Architect Reviewer](prompts.md#architect-reviewer).

**On completion:**
- Parse JSON: `{"review_file": "...", "has_critical_issues": true/false}`
- **Update `workflow-state.json`:** set `step: "2.2"`, `artifacts.architecture_review` to the returned path, increment `review_counts.architecture`
- If no critical issues → **Phase 2 complete**, proceed to Phase 3
- If critical issues AND review #1 → proceed to Step 2.3
- If critical issues AND review #2 → set `status: "paused"`, **STOP**, escalate to user

### Step 2.3 — Architect Revision

Launch `Task` with `subagent_type: "orchestra-architect"`. Pass the prompt from [prompts.md → Architect: Revision](prompts.md#architect-revision).

**On completion:**
- **Update `workflow-state.json`:** set `step: "2.3"`
- Check blocking questions (update state if paused)
- Return to Step 2.2 for 2nd review

**Max cycles:** architect → review → architect → review (2 reviews, 1 revision)

## Phase 3: Planning

**Goal:** Produce an approved development plan with detailed task descriptions.

### Step 3.1 — Run Planner

Launch `Task` with `subagent_type: "orchestra-planner"`. Pass the prompt from [prompts.md → Planner: Initial](prompts.md#planner-initial).

**On completion:**
- **Update `workflow-state.json`:** set `phase: 3`, `step: "3.1"`, `artifacts.plan_file: "plan.md"`
- Check if `open-questions.md` was created → set `status: "paused"`, **STOP** if yes, present to user
- If no questions → proceed to Step 3.2

### Step 3.2 — Run Plan Reviewer

Launch `Task` with `subagent_type: "orchestra-planner-reviewer"`. Pass the prompt from [prompts.md → Planner Reviewer](prompts.md#planner-reviewer).

**On completion:**
- Read the plan-review.md to determine the final decision
- **Update `workflow-state.json`:** set `step: "3.2"`, `artifacts.plan_review: "plan-review.md"`, increment `review_counts.planning`
- If approved → **Phase 3 complete**, proceed to Phase 3.5
- If critical issues AND review #1 → proceed to Step 3.3
- If critical issues AND review #2 → set `status: "paused"`, **STOP**, escalate to user

### Step 3.3 — Planner Revision

Launch `Task` with `subagent_type: "orchestra-planner"`. Pass the prompt from [prompts.md → Planner: Revision](prompts.md#planner-revision).

**On completion:**
- **Update `workflow-state.json`:** set `step: "3.3"`
- Check for open questions (update state if paused)
- Return to Step 3.2 for 2nd review

**Max cycles:** planner → review → planner → review (2 reviews, 1 revision)

## Phase 3.5: Pre-flight Check

**Goal:** Verify the environment is ready for development before spending tokens on developer agents.

This step is executed by the orchestrator directly (no subagent needed).

### Checks:

1. **Task files exist** — verify all `tasks/task-X-Y.md` files referenced in `plan.md` are present and non-empty
2. **Build works** — run `bitrix build` or `npm run build` from the relevant directory
3. **Existing tests pass** — run the test suite to establish a baseline
4. **Lint is clean** — run `ReadLints` on files that will be modified (listed in task descriptions)

### On completion:

- Create `{output_dir}/preflight-report.md` with results
- **Update `workflow-state.json`:** set `step: "3.5"`, `artifacts.preflight_report: "preflight-report.md"`
- If all checks pass → proceed to Phase 4
- If critical failures (build broken, missing task files) → set `status: "paused"`, **STOP**, present report to user
- If non-critical issues (some lint warnings) → note in report, proceed to Phase 4

## Phase 4: Development (Parallel Execution)

**Goal:** Implement all tasks from the plan. Each task gets a dedicated Developer agent and Developer Reviewer agent.

### Task Execution Strategy

Read `plan.md` to get the ordered task list with dependencies. Build a dependency graph:

1. **Parse dependencies** from `plan.md` — each task lists its dependencies explicitly
2. **Identify parallelizable batches** — tasks with all dependencies satisfied can run in parallel
3. **Execute in waves** — launch up to 4 tasks simultaneously (Cursor limit), wait for all to complete, then launch the next batch

```
Wave 1: [task-1-1, task-1-2]  (no dependencies, parallel)
Wave 2: [task-1-3, task-2-1]  (depend on wave 1, parallel)
Wave 3: [task-2-2]            (depends on task-2-1, sequential)
```

**Constraint:** Tasks modifying the same file MUST NOT run in parallel — check file lists from task descriptions.

### For each task (task-X-Y):

#### Step 4.1 — Run Developer

Launch a **new** `Task` with `subagent_type: "orchestra-developer"`. Pass the prompt from [prompts.md → Developer: New Task](prompts.md#developer-new-task).

**Important:** Each task must be a fresh `Task` call — do NOT resume a previous developer agent.

**On completion:**
- Parse the developer's response
- **Update `workflow-state.json`:** set `phase: 4`, `step: "4.1-{X}-{Y}"`, add entry to `completed_tasks` array with `id`, `description`, `files_created`, `files_modified`, `classes_added`, `methods_added`, `status: "in_review"`
- Check for `open-questions.md` → set `status: "paused"`, **STOP** if present
- Check for `ARCHITECTURE_ISSUE` or `SPEC_ISSUE` markers → trigger [Rollback Protocol](#rollback-protocol) if present
- Proceed to Step 4.2

#### Step 4.2 — Run Developer Reviewer

Launch a **new** `Task` with `subagent_type: "orchestra-developer-reviewer"`. Pass the prompt from [prompts.md → Developer Reviewer](prompts.md#developer-reviewer).

**On completion:**
- **Update `workflow-state.json`:** set `step: "4.2-{X}-{Y}"`
- If approved → update task's `status` to `"completed"` in `completed_tasks`, move to next task
- If changes required → proceed to Step 4.3

#### Step 4.3 — Developer Fix

Launch a **new** `Task` with `subagent_type: "orchestra-developer"`. Pass the prompt from [prompts.md → Developer: Fix Feedback](prompts.md#developer-fix-feedback).

**On completion:** → proceed to Step 4.4

#### Step 4.4 — Re-review

Launch a **new** `Task` with `subagent_type: "orchestra-developer-reviewer"`. Pass the prompt from [prompts.md → Developer Reviewer](prompts.md#developer-reviewer).

**On completion:**
- **Update `workflow-state.json`:** set `step: "4.4-{X}-{Y}"`
- If approved → update task's `status` to `"completed"` in `completed_tasks`, move to next task
- If still has issues → update task's `status` to `"completed_with_issues"`, log unresolved issues, move to next task

**Max cycles per task:** developer → review → fix → re-review (2 reviews, 1 fix)

## Rollback Protocol

When a developer or reviewer identifies a fundamental issue in the architecture or TS during Phase 4:

1. Developer/Reviewer marks an issue as `ARCHITECTURE_ISSUE` or `SPEC_ISSUE` in their report
2. Orchestrator creates `{output_dir}/rollback-request.md` with:
   - Description of the problem
   - Which task discovered it
   - Impact on remaining tasks
3. Orchestrator **STOPS** and presents to user:

```
⚠️ Fundamental issue discovered during task {X-Y}:

{problem_description}

Options:
(a) Workaround — developer works around the issue in the current task
(b) Partial rollback — re-run architect/planner for the affected component only
(c) Full rollback to Phase {N} — re-run from that phase forward
```

4. User chooses an option, orchestrator acts accordingly

## Blocking Questions Protocol

When any agent returns blocking questions or `open-questions.md`:

1. **STOP** the workflow immediately
2. **Batch questions** — if the current phase can anticipate questions for the next phase, include them:

```
Workflow paused — {role} has blocking questions:

### Current phase questions:
1. {question_1}
2. {question_2}

### Anticipated questions for next phase:
3. {anticipated_question_1}

Please answer these questions to continue the workflow.
```

3. Wait for user's answers
4. Resume by re-running the agent with answers included

### Question Anticipation

In the Analyst prompt, the analyst is instructed to add an "Anticipated Architecture Questions" section to the TS when obvious architectural ambiguities exist. The orchestrator should include these in the blocking questions batch after Phase 1 (if present), reducing the number of workflow pauses.

## Escalation Rules

| Phase | Max Reviews | On Unresolved Critical Issues |
|-------|-------------|-------------------------------|
| Analysis | 2 reviews, 1 revision | STOP, involve user |
| Architecture | 2 reviews, 1 revision | STOP, involve user |
| Planning | 2 reviews, 1 revision | STOP, involve user |
| Development | 1 review, 1 fix per task | Move to next task, log unresolved |

When escalating:

```
Workflow paused — unresolved critical issues after {N} review cycles in {phase}:

Review file: {review_file_path}

The following critical issues remain unresolved:
{list_of_issues}

Please review and provide guidance.
```

## Context Management

### Project Context File

At workflow start, create `{output_dir}/project-context.md` containing:
- **Documentation directory:** `{docs_dir}` (or "not specified" if not provided) — agents update docs here
- Relevant README content
- Project documentation excerpts (from `{docs_dir}` if available)
- Architecture documentation excerpts
- Any other project docs relevant to the task

All agents read this file themselves instead of receiving inline project description. This eliminates duplication across agent calls.

### Workflow State (workflow-state.json)

Maintained by the orchestrator throughout the workflow. **You MUST update this file after EVERY step** — each step's "On completion" section specifies exactly which fields to update. Write the updated JSON to disk immediately after parsing the subagent's response, BEFORE making any branching decisions.

```json
{
  "pipeline": "full",
  "output_dir": "{output_dir}",
  "docs_dir": "{docs_dir or null}",
  "task_description": "Brief task summary",
  "phase": 1,
  "step": "1.2",
  "status": "in_progress",
  "review_counts": {
    "analysis": 0,
    "architecture": 0,
    "planning": 0
  },
  "artifacts": {
    "ts_file": "technical-specification.md",
    "ts_review": null,
    "architecture_file": null,
    "architecture_review": null,
    "plan_file": null,
    "plan_review": null,
    "preflight_report": null
  },
  "completed_tasks": [
    {
      "id": "1-1",
      "description": "Create service stubs",
      "files_created": ["path/to/file.js"],
      "files_modified": ["path/to/other.js"],
      "classes_added": ["MyService"],
      "methods_added": ["MyService.doWork"],
      "status": "completed"
    }
  ]
}
```

### Completed Tasks Context

Instead of accumulating a growing text summary, pass the `completed_tasks` array from `workflow-state.json` to each new developer agent as structured JSON. The developer reads it to understand what was already done without parsing prose.

### Extracting affected_files for Developer prompts

Before launching each Developer agent, read the task file (`{output_dir}/tasks/task-X-Y.md`) and extract file paths from the "Description of Changes" / "New Files" / "Changes to Existing Files" sections. Pass this list as `{list_of_files_from_task_description}`.

### Minimize Orchestrator Context

- Do NOT store full subagent response bodies in your working context. After parsing JSON/decision, retain only what is needed.
- For **developer-reviewer** responses: retain only the verdict and critical issues list.
- For **developer** responses: retain only the status and changed files list (update `workflow-state.json`).
- For **analyst/architect/planner** responses: retain only file paths and blocking questions.

## Workflow Persistence

The orchestrator persists state via `workflow-state.json` after every step. On start, check for existing state in priority order:

### Priority 1: Recovery Summary

1. Check if `{output_dir}/recovery-summary.md` exists
2. If yes → this is a recovered workflow (produced by `orchestra-workflow-recovery` agent). Follow the [Recovery Resume](#recovery-resume) procedure
3. If no → fall through to Priority 2

### Priority 2: Workflow State

1. Check if `{output_dir}/workflow-state.json` exists
2. If yes → present to user:

```
Found existing workflow state in {output_dir}:
- Pipeline: {pipeline}
- Current phase: {phase}, step: {step}
- Status: {status}
- Completed tasks: {count}

Options:
(a) Resume from where it stopped
(b) Start over (existing artifacts will be overwritten)
```

3. If resuming → read state and continue from the saved step
4. If starting over → reinitialize state

### Priority 3: Fresh Start

If neither file exists → proceed with normal Getting Started flow (steps 4–9).

## Recovery Resume

When `recovery-summary.md` is found in the output directory:

1. **Read `recovery-summary.md`** and extract:
   - `Pipeline` — the pipeline type (full / medium / simple)
   - `Original Task` — the task description
   - `Phases to Execute` — ordered list of phases that still need to run, with the reason for each (restart / not started / continue from task X-Y)
   - `Critical Data for Restart` — unresolved questions, user decisions needed
   - `Reconstructed workflow-state.json` — the full JSON block at the end of the file

2. **Present to user for confirmation:**

```
Found recovery summary in {output_dir}:
- Pipeline: {pipeline}
- Last completed phase: {last completed phase from "Phase Status"}
- Resume from: Phase {N} — {reason from "Phases to Execute"}
- Unresolved questions: {list from "Critical Data for Restart", or "none"}

Options:
(a) Resume from recovered state
(b) Start over (existing artifacts will be overwritten)
```

3. **If user confirms resume:**
   - Write the `Reconstructed workflow-state.json` from the summary to `{output_dir}/workflow-state.json` (overwrite if needed)
   - Use `Pipeline` as the pipeline type — skip complexity classification (step 4)
   - Use `Original Task` as the task description — skip collecting it again (step 1)
   - Skip context/directory setup (steps 5–8) — these are already established
   - If `Unresolved questions` or `User decisions needed` are non-empty → present them to user and wait for answers before proceeding
   - Start the pipeline from the **first phase** listed in `Phases to Execute`, at the step indicated by the reason (e.g., "restart" → run from step X.1; "continue from task 2-3" → resume Phase 4 from that task)
   - Delete `recovery-summary.md` after the first phase step completes successfully

4. **If user wants to start over:**
   - Delete `recovery-summary.md`
   - Reinitialize state, proceed with normal Getting Started flow (steps 4–9)

## Directory Structure

```
{output_dir}/
├── technical-specification.md       # TS from analyst
├── ts-review.md                     # TS review from analyst-reviewer
├── architecture.md                  # From architect (full pipeline only)
├── architecture-review.md           # From architect-reviewer
├── plan.md                          # From planner
├── plan-review.md                   # From planner-reviewer
├── project-context.md               # Project docs snapshot
├── workflow-state.json              # Workflow state for persistence
├── preflight-report.md              # Pre-flight check results
├── open-questions.md                # Blocking questions (when paused)
├── recovery-summary.md              # Recovery state (from orchestra-workflow-recovery)
├── rollback-request.md              # Rollback request (if triggered)
├── tasks/                           # Task descriptions from planner
│   ├── task-1-1.md
│   ├── task-1-2.md
│   ├── task-2-1.md
│   └── ...
├── reports/                         # Developer reports & code reviews
│   ├── task-1-1-report.md           # Developer's implementation result
│   ├── task-1-1-review.md           # Code reviewer's verdict
│   └── ...
└── tests/                           # Test reports
    ├── task-1-1-test.md             # Test results for task 1-1
    └── ...
```

## Key Principles

1. **Output directory is REQUIRED** — never start without it
2. **Classify before executing** — wrong pipeline wastes resources
3. **Earlier phases = more scrutiny** — unresolved ambiguity causes cascading failures
4. **Analyst, Architect, Planner do NOT write code** — documents only
5. **Top-down development** — stubs and interfaces first, implementation later
6. **Parallelize when possible** — independent tasks run simultaneously in Phase 4
7. **Persist state** — workflow can resume after interruption
8. **Agents read project-context.md** — no inline duplication of project docs
9. **Every task links to use cases** — traceability from TS to code
10. **Developer updates documentation** — project docs (path from `project-context.md`), README after each task
11. **Rollback is possible** — fundamental issues can trigger partial re-runs
