# Orchestrator Prompt Templates

Prompt templates for each step of the development workflow. Replace placeholders in `{curly_braces}` with actual values.

`{output_dir}` is the user-specified output directory for all workflow artifacts.

---

## Analyst: Initial

```
Create a technical specification based on the following task description.

Task description:
<task_description>
{user_task_description}
</task_description>

{IF_EXISTING_PROJECT}
This is an enhancement to an existing project. Read the project context file to understand the current system before writing the TS:

Project context: {output_dir}/project-context.md
{/IF_EXISTING_PROJECT}

Output directory: {output_dir}/

Save the TS to: {output_dir}/technical-specification.md

Additionally, if you see obvious architectural ambiguities, add a section "Anticipated Architecture Questions" at the end of the TS. This helps batch questions across phases and reduce workflow pauses.

Return JSON:
{"ts_file": "{output_dir}/technical-specification.md", "blocking_questions": [...]}

Pay maximum attention to unclear points. You are at the earliest stage — unresolved uncertainty now will cause the project to fail. Ask questions rather than make assumptions.
```

---

## Analyst: Revision

```
Revise the technical specification based on reviewer feedback.

TS file to revise: {output_dir}/technical-specification.md
Reviewer feedback: {output_dir}/ts-review.md

Original task description:
<task_description>
{user_task_description}
</task_description>

{IF_EXISTING_PROJECT}
Project context: {output_dir}/project-context.md
{/IF_EXISTING_PROJECT}

IMPORTANT: Fix ONLY the issues listed in the review. Do NOT change parts of the TS unrelated to the feedback. Preserve document structure and numbering.

Return JSON:
{"ts_file": "{output_dir}/technical-specification.md", "blocking_questions": [...]}
```

---

## Analyst: With User Answers

Use when resuming after blocking questions were answered.

```
Create/revise the technical specification. The user has answered your previous blocking questions.

Task description:
<task_description>
{user_task_description}
</task_description>

User's answers to your questions:
<answers>
{user_answers}
</answers>

{IF_REVISION}
TS file to revise: {output_dir}/technical-specification.md
{/IF_REVISION}

{IF_EXISTING_PROJECT}
Project context: {output_dir}/project-context.md
{/IF_EXISTING_PROJECT}

Save the TS to: {output_dir}/technical-specification.md

Return JSON:
{"ts_file": "{output_dir}/technical-specification.md", "blocking_questions": [...]}
```

---

## Analyst Reviewer

```
Review the technical specification for completeness, consistency, and compliance with the task description.

TS file: {output_dir}/technical-specification.md

Original task description:
<task_description>
{user_task_description}
</task_description>

{IF_EXISTING_PROJECT}
Project context: {output_dir}/project-context.md
{/IF_EXISTING_PROJECT}

Save review to: {output_dir}/ts-review.md

Return JSON:
{"review_file": "{output_dir}/ts-review.md", "has_critical_issues": true/false}
```

---

## Architect: Initial

```
Design the system architecture based on the approved technical specification.

TS file: {output_dir}/technical-specification.md

{IF_EXISTING_PROJECT}
This is an enhancement to an existing project. Read the project context file to understand the current architecture before designing:

Project context: {output_dir}/project-context.md
{/IF_EXISTING_PROJECT}

Design:
1. Functional architecture (components, functions, dependencies)
2. System architecture (components, interactions, technologies)
3. Data model (entities, attributes, relationships, indexes)
4. Interfaces (external APIs, internal interfaces)
5. Technology stack
6. Deployment recommendations

Save architecture to: {output_dir}/architecture.md

Return JSON:
{"architecture_file": "{output_dir}/architecture.md", "blocking_questions": [...]}

Pay attention to open questions. Wrong architectural decisions are very expensive to fix later.

If the TS contains an "Anticipated Architecture Questions" section, check if those questions are answered by the TS itself. If not, include them in your blocking_questions.
```

---

## Architect: Revision

```
Revise the architecture based on reviewer feedback.

Architecture file: {output_dir}/architecture.md
Review file: {output_dir}/architecture-review.md
TS file: {output_dir}/technical-specification.md

{IF_EXISTING_PROJECT}
Project context: {output_dir}/project-context.md
{/IF_EXISTING_PROJECT}

IMPORTANT: Fix ONLY the issues listed in the review. Do NOT change parts unrelated to the feedback. Preserve document structure.

Return JSON:
{"architecture_file": "{output_dir}/architecture.md", "blocking_questions": [...]}
```

---

## Architect: With User Answers

```
Design/revise the system architecture. The user has answered your previous blocking questions.

TS file: {output_dir}/technical-specification.md

User's answers to your questions:
<answers>
{user_answers}
</answers>

{IF_REVISION}
Architecture file to revise: {output_dir}/architecture.md
{/IF_REVISION}

{IF_EXISTING_PROJECT}
Project context: {output_dir}/project-context.md
{/IF_EXISTING_PROJECT}

Save architecture to: {output_dir}/architecture.md

Return JSON:
{"architecture_file": "{output_dir}/architecture.md", "blocking_questions": [...]}
```

---

## Architect Reviewer

```
Review the system architecture for technical adequacy, TS compliance, and feasibility.

Architecture file: {output_dir}/architecture.md
TS file: {output_dir}/technical-specification.md

{IF_EXISTING_PROJECT}
Project context: {output_dir}/project-context.md
{/IF_EXISTING_PROJECT}

Pay special attention to:
- Data model completeness and correctness
- All use cases from TS are covered
- Compatibility with existing project (if enhancement)

Save review to: {output_dir}/architecture-review.md

Return JSON:
{"review_file": "{output_dir}/architecture-review.md", "has_critical_issues": true/false}
```

---

## Planner: Initial

```
Create a detailed development plan based on the TS and architecture.

TS file: {output_dir}/technical-specification.md
{IF_FULL_PIPELINE}
Architecture file: {output_dir}/architecture.md
{/IF_FULL_PIPELINE}

{IF_EXISTING_PROJECT}
This is an enhancement to an existing project. Read the project context to specify exact file paths and locations for changes:

Project context: {output_dir}/project-context.md
{/IF_EXISTING_PROJECT}

Output directory: {output_dir}/

Create:
- plan.md — overall plan with task sequence, phases, dependencies, UC coverage table
- tasks/task-X-Y.md — detailed description for each task (X = phase, Y = task number)
- open-questions.md — only if there are blocking ambiguities

Key requirements:
1. Top-down approach: stubs and interfaces first, implementation later
2. E2E tests from the very first task (verifying hardcoded results at stub stage)
3. Every task must link to use cases from the TS
4. Each task must specify test cases (E2E, unit, regression)
5. Include deployment tasks based on architect's recommendations
6. Include a use case coverage table in plan.md
7. For each task, specify explicit dependencies in a machine-readable format: `Dependencies: task-1-1, task-1-3` (or `Dependencies: none`)
8. When tasks have no shared file dependencies, mark them as parallelizable

File naming convention:
- Task descriptions: tasks/task-X-Y.md
- Developer reports (created by developer): reports/task-X-Y-report.md
- Test reports (created by developer): tests/task-X-Y-test.md
- Code reviews (created by reviewer): reports/task-X-Y-review.md
```

---

## Planner: Revision

```
Revise the development plan based on reviewer feedback.

Plan review: {output_dir}/plan-review.md
TS file: {output_dir}/technical-specification.md
{IF_FULL_PIPELINE}
Architecture file: {output_dir}/architecture.md
{/IF_FULL_PIPELINE}

{IF_EXISTING_PROJECT}
Project context: {output_dir}/project-context.md
{/IF_EXISTING_PROJECT}

Output directory: {output_dir}/

Fix ONLY the issues listed in the review. If use cases are not covered — add tasks. If task descriptions are missing — create them. Do NOT change tasks unrelated to the feedback.
```

---

## Planner Reviewer

```
Review the development plan for completeness and consistency.

TS file: {output_dir}/technical-specification.md
{IF_FULL_PIPELINE}
Architecture file: {output_dir}/architecture.md
{/IF_FULL_PIPELINE}
Plan file: {output_dir}/plan.md
Task files directory: {output_dir}/tasks/

Your checks:

### Formal checks:
1. All use cases from TS are covered by tasks (check the coverage table)
2. Every task in the plan has a corresponding task-X-Y.md file with detailed description
3. Plan has proper structure (phases, dependencies, UC coverage table)
4. Each task description has required sections (Related UCs, Description of Changes, Test Cases, Acceptance Criteria)
5. Dependencies are explicitly listed for each task in machine-readable format

### Content checks:
6. Task descriptions reference correct file paths that exist in the project (for existing project enhancements)
7. Method names and class names in tasks are consistent with each other and with the architecture
8. Task order follows top-down approach (stubs and interfaces before implementation)
9. No two tasks modify the same method in conflicting ways
10. Dependencies between tasks are logically correct (a task does not depend on something created after it)

Do NOT evaluate implementation logic or code quality — only structural and consistency checks.

Save review to: {output_dir}/plan-review.md
```

---

## Developer: New Task

```
Implement task {task_id}: {task_brief_description}

Task description file: {output_dir}/tasks/task-{X}-{Y}.md

Read the task description carefully and implement exactly what is specified.

{IF_EXISTING_PROJECT}
Follow existing patterns, coding standards, and linter rules.
Project context: {output_dir}/project-context.md
{/IF_EXISTING_PROJECT}

{IF_PREVIOUS_TASKS}
Previously completed tasks (do NOT re-implement these):
<previous_tasks>
{completed_tasks_json}
</previous_tasks>
{/IF_PREVIOUS_TASKS}

Key files affected by this task (start here, do not explore the entire codebase):
<affected_files>
{list_of_files_from_task_description}
</affected_files>

After implementation:
1. Run all tests specified in the task description
2. Run regression tests (all existing project tests)
3. Save implementation report to: {output_dir}/reports/task-{X}-{Y}-report.md
4. Save test report to: {output_dir}/tests/task-{X}-{Y}-test.md
5. Update documentation (if docs_dir is specified in project-context.md):
   - Update relevant docs in the docs directory specified in project-context.md
   - Update project README if a new module was added

If you discover a fundamental issue with the architecture or TS, prefix your report with ARCHITECTURE_ISSUE or SPEC_ISSUE and describe the problem clearly.

Do NOT add features not specified in the task. Do NOT refactor unrelated code.

If you encounter blocking ambiguities, create {output_dir}/open-questions.md and return it.
```

---

## Developer: Simple Task

For the Simple pipeline — no formal task file, user's description is the spec.

```
Implement the following change:

<task_description>
{user_task_description}
</task_description>

{IF_EXISTING_PROJECT}
Follow existing patterns, coding standards, and linter rules.
Project context: {output_dir}/project-context.md
{/IF_EXISTING_PROJECT}

After implementation:
1. Run relevant tests
2. Save implementation report to: {output_dir}/reports/task-report.md
3. Save test report to: {output_dir}/tests/task-test.md
4. Update relevant project documentation if files were added or APIs changed

Do NOT add features not specified. Do NOT refactor unrelated code.
```

---

## Developer: Fix Feedback

```
Fix the code reviewer's feedback for task {task_id}.

Reviewer feedback file: {output_dir}/reports/task-{X}-{Y}-review.md

Original task description: {output_dir}/tasks/task-{X}-{Y}.md

Key files affected (focus here):
<affected_files>
{list_of_files_from_task_description}
</affected_files>

IMPORTANT:
- Fix ONLY the issues mentioned in the feedback
- Do NOT refactor other code
- Do NOT add improvements not requested in the feedback
- Re-run all tests after fixes
- Update implementation report: {output_dir}/reports/task-{X}-{Y}-report.md
- Update test report: {output_dir}/tests/task-{X}-{Y}-test.md
```

---

## Developer: With User Answers

```
Continue implementing task {task_id}. The user has answered your open questions.

Task description: {output_dir}/tasks/task-{X}-{Y}.md

User's answers:
<answers>
{user_answers}
</answers>

Continue implementation according to the task description, taking into account the user's answers.

After implementation:
1. Run all tests specified in the task
2. Run regression tests
3. Save implementation report to: {output_dir}/reports/task-{X}-{Y}-report.md
4. Save test report to: {output_dir}/tests/task-{X}-{Y}-test.md
5. Update documentation
```

---

## Developer Reviewer

```
Review the implementation of task {task_id}.

Task description: {output_dir}/tasks/task-{X}-{Y}.md
Developer report: {output_dir}/reports/task-{X}-{Y}-report.md
Test report: {output_dir}/tests/task-{X}-{Y}-test.md

Check:
1. All requirements from the task description are implemented
2. Acceptance criteria are met
3. E2E tests pass and verify correct behavior
4. For stub tasks: stubs are properly created with doc comments
5. For implementation tasks: stubs are replaced with real logic, tests updated
6. Regression tests pass (verify in the test report)
7. No backward compatibility issues
8. Documentation is updated (project docs, README)
9. No code duplication — existing methods/functions are reused
10. Generated artifacts are in {output_dir}/

Save your review to: {output_dir}/reports/task-{X}-{Y}-review.md

Include the overall assessment and list of issues if any.
```

---

## Developer Reviewer: Simple Task

```
Review the implementation of the task.

Task description:
<task_description>
{user_task_description}
</task_description>

Developer report: {output_dir}/reports/task-report.md
Test report: {output_dir}/tests/task-test.md

Check:
1. The change matches the task description
2. Tests pass
3. No backward compatibility issues
4. Documentation updated if needed

Save your review to: {output_dir}/reports/task-review.md
```
