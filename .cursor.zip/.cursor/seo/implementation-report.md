# SEO Implementation Report — Ti-WarmLAB

**Дата:** май 2026  
**Статус:** ✅ Все этапы выполнены

---

## Изменённые файлы

### Новые файлы:
- `app/sitemap.ts` — динамический sitemap: статические страницы + все товары + все категории из PocketBase
- `app/robots.ts` — robots.txt: разрешить `/`, запретить `/checkout`, `/order/`, `/api/`; указать sitemap URL
- `lib/breadcrumbs.ts` — утилита `buildBreadcrumbJsonLd()` для генерации BreadcrumbList JSON-LD

### Изменённые файлы:

#### SEO-константы и метаданные
- `lib/seo.ts` — обновлены `SITE_TITLE` и `DEFAULT_DESCRIPTION` (новые SEO-ключи)
- `app/layout.tsx` — расширен список `keywords`: добавлены "соевый воск", "натуральные свечи", "формовые свечи", "свечи Санкт-Петербург", "свечи с доставкой"
- `app/page.tsx` — обновлены title/description в `generateMetadata`; обновлено описание WebSite JSON-LD; добавлен Organization JSON-LD
- `app/catalog/page.tsx` — обновлены title/description
- `app/catalog/[categorySlug]/page.tsx` — шаблон `${category.name} — купить | Ti-WarmLAB | Соевый воск`
- `app/contacts/layout.tsx` — новый title с упоминанием Санкт-Петербурга; Breadcrumbs JSON-LD
- `app/philosophy/layout.tsx` — новый title "О нас — Ti-WarmLAB: свечи ручной работы из Санкт-Петербурга"; Breadcrumbs JSON-LD
- `app/delivery/layout.tsx` — новый title "Доставка свечей по России — СДЭК и самовывоз | Ti-WarmLAB"; Breadcrumbs JSON-LD

#### Контент компонентов
- `components/landing/hero.tsx` — H1 заменён на "Свечи ручной работы из соевого воска" + span "Ti-WarmLAB"; обновлён alt hero-изображения
- `components/landing/about.tsx` — третий абзац обновлён: добавлено упоминание Санкт-Петербурга и доставки; обновлён alt
- `components/landing/features.tsx` — H2 "Натуральный соевый воск и хлопковый фитиль"; обновлён основной абзац (горит в 1,5–2 раза дольше, без копоти); обновлены описания в 4 карточках waxPoints; обновлён alt
- `components/landing/cta.tsx` — абзац: добавлено "Производим в Санкт-Петербурге, доставляем по всей России через СДЭК"
- `app/catalog/layout.tsx` — H1 "Купить свечи ручной работы из соевого воска"; вводный текст ~80 слов; информационный блок "Почему соевый воск" ~165 слов; Breadcrumbs JSON-LD
- `app/philosophy/page.tsx` — H1 "Ti-WarmLAB — авторские свечи из соевого воска ручной работы"; обновлены карточки philosophyItems; расширены секции текста с упоминанием Санкт-Петербурга; добавлена секция "Соевый воск и хлопковый фитиль — осознанный выбор"; обновлён alt
- `app/delivery/page.tsx` — H1 "Доставка и оплата свечей Ti-WarmLAB"; добавлена FAQ-секция "Часто задаваемые вопросы" (4 вопроса-ответа); FAQ JSON-LD (FAQPage Schema)
- `app/contacts/page.tsx` — H1 "Контакты Ti-WarmLAB в Санкт-Петербурге"

#### Structured Data / JSON-LD
- `app/page.tsx` — добавлен Organization JSON-LD (имя, URL, лого, foundingLocation СПб, contactPoint, sameAs)
- `app/delivery/page.tsx` — добавлен FAQPage JSON-LD (4 вопроса)
- `app/catalog/layout.tsx` — BreadcrumbList: Главная → Каталог
- `app/catalog/[categorySlug]/page.tsx` — BreadcrumbList: Главная → Каталог → Категория
- `app/product/[slug]/page.tsx` — BreadcrumbList: Главная → Каталог → Товар
- `app/philosophy/layout.tsx` — BreadcrumbList: Главная → О нас
- `app/delivery/layout.tsx` — BreadcrumbList: Главная → Доставка
- `app/contacts/layout.tsx` — BreadcrumbList: Главная → Контакты

---

## Что не вошло

- **ContactPage JSON-LD** на `/contacts` — не добавлен (минимальная схема, низкий приоритет)
- **Product page metadata templates** — шаблоны для конкретных товаров (Лапка, Зайчик и т.д.) не внедрены: они управляются через `buildProductMetadata` из `lib/seo.ts`, которая строится из данных PocketBase. Обновление title/description конкретных товаров нужно делать в PocketBase Admin UI.
- **H1 категорийных страниц** (`/catalog/[categorySlug]`) — H1 на этих страницах формируется через `CatalogContent`, который не был изменён (чтобы не сломать фильтрацию). Шаблон `Купить {categoryName} — ручная работа из соевого воска` нужно добавить в `CatalogContent`.

---

## Примечания

- Все изменения не нарушают существующий дизайн и функциональность
- Линтер: ошибок не обнаружено ни в одном из изменённых файлов
- `NEXT_PUBLIC_BASE_URL` используется через `getBaseUrl()` из `lib/seo.ts`
- Sitemap revalidate = 3600 (каждый час)
